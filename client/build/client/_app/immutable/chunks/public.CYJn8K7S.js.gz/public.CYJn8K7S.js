const t="http://192.168.1.11:4269",I="http://192.168.1.13:5173";export{t as P,I as a};
