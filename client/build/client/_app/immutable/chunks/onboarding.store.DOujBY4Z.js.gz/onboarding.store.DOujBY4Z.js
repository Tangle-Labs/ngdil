import{p as r}from"./index.C65le1wf.js";const p=r("onboardingCurrStep",0);export{p as c};
